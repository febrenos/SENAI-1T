# MATE O DRAGÃO
## 1.0 - MASTER

Você está onde tudo começou. A partir desse código o jogo irá evoluir em passos e essa evolução será feita por _branches_.
Quando estiver pronto para avançar, digite em sua interface de linha de comando predileta o seguinte comando: **git** **checkout** metodos.