namespace MateODragao.Models
{
    public class Dragao
    {
        public string Nome {get;set;}
        public int Forca {get;set;}
        public int Destreza {get;set;}
        public int Inteligencia {get;set;}
        public int Vida {get;set;}
        

    }
}