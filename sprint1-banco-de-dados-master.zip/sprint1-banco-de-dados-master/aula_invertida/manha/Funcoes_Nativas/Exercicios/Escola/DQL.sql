-- DQL

Select * From Aluno
Select * From Materia
Select * from Nota

