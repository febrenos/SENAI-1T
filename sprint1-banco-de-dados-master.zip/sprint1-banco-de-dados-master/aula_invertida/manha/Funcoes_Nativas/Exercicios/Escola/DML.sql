-- DML

Insert into Aluno values (
	'Ana'
);
Insert into Aluno values (
	'Bruno'
);
Insert into Aluno values (
	'Nick'
);
Insert into Aluno values (
	'Carlos'
);
Insert into Aluno values (
	'Eduardo'
);

Insert into Materia values (
	'Matematica'
);
Insert into Materia values (
	'Portugues'
);
Insert into Materia values (
	'Ciencias'
);
Insert into Materia values (
	'Ingles'
);
Insert into Materia values (
	'Historia'
);
Insert into Materia values (
	'Geografia'
);
Insert into Nota values (
	'1.0',1,1
);
Insert into Nota values (
	'2.5',2,2
);
Insert into Nota values (
	'3.0',2,3
);
Insert into Nota values (
	'4.5',3,3
);
Insert into Nota values (
	'5.0',4,4
);
Insert into Nota values (
	'2.0',5,5
);
Insert into Nota values (
	'3.0',5,6
);