# Procedures

Grupo 2 

- Roteiro

- Slide Apresentação / Material de Apoio

- Scrips

- Link do Kahoot

- video 
