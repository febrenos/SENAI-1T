# Eventos-SQL
Repositório do trabalho em grupo referente a Eventos do SQL Server do curso técnico de desenvolvimento de sistemas.
