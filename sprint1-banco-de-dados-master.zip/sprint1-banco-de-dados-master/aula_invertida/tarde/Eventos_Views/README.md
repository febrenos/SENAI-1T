# Extended-Events-Views---Projeto-Aula
Aula feita para executar um projeto do senai
