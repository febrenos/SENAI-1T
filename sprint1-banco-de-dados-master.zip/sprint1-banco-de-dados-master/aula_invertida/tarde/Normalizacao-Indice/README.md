# Normaliza-o-Indice
