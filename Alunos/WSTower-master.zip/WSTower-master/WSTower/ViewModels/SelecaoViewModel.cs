﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WSTower.Domains;

namespace WSTower.ViewModels
{
    public class SelecaoViewModel
    {
        public Selecao Selecao { get; set; }
        public int Pontos { get; set; }
    }
}
